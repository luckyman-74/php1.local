<?php
return [1=>'file1.jpg',2=>'file2.jpg',3=>'file3.jpg',4=>'file4.jpg'];