<?php

$var = 'PHP';