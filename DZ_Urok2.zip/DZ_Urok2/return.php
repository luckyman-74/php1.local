<?php
$var = 'PHP';
return $var;