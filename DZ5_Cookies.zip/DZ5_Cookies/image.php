<!doctype html>
<html lang="ru">

<body>

</body>
</html>
<a href="/DZ5_Cookies">На главную</a>
<hr>
<img width="50%" src="/DZ5_Cookies/images/<?php echo $_GET['file']; ?>">
